# Curl commands

### Basic curl command
curl http://localhost:8090

### Head request
curl -I  localhost:8090

### Check options
curl -i --request-target "*" -X OPTIONS http://localhost:8090